const bookshelf = [];// creating array to put the books like bookshelf itself.

module.exports = bookshelf; // exporting the module to use in local directory.
